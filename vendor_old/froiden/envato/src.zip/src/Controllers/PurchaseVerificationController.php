<?php

namespace Froiden\Envato\Controllers;

use Illuminate\Routing\Controller;
use Froiden\Envato\Traits\AppBoot;

class PurchaseVerificationController extends Controller
{
   use AppBoot;
}
