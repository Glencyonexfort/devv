<div class="row">
    <div class="col-md-12">
        <h4 class="box-title" id="structure">Update Log</h4>
        <pre>
    <p>
        <strong>Producct Updates Log</strong>
        ├──
        │
        │
        │   └── <strong>Version 1.0.0</strong>
        │       └── Bug fixes
        │
        └──
    </p>
                                        </pre>
    </div>
</div>
